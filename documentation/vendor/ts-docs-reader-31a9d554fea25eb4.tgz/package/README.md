# ts-docs-fresh

A documentation reader for a TypeScript project. It covers the API reference,
guides, Getting started and Files, and types unfold in place. It reads the
project's `documentation/ts-docs.json` and answers type questions with the
native TypeScript compiler (`typescript@7.1.0-beta`).

## Use it in a project

Requirements: Node 24 and pnpm. The project's own dependencies must be
installed, because the compiler reads their declarations, and so must any
declarations its build generates (see "What a consumer provides").

The reader lives in `reader/` of the ts-docs repository, beside the original
engine at its root, as its own pnpm project with its own lockfile. It is not
published to any registry. A project takes the packed package of a reviewed
commit from CI, and records which:

```sh
# from the reader CI run of the commit the project adopts:
#   the ts-docs-fresh-package artifact holds ts-docs-fresh-0.1.0.tgz and its SHA256
# in the project: commit the tarball and a receipt naming the commit and that digest
#   package.json: "devDependencies": { "ts-docs-fresh": "file:documentation/vendor/ts-docs-reader-<sha>.tgz" }
pnpm install              # records the tarball's integrity in pnpm-lock.yaml
pnpm install --frozen-lockfile   # every later checkout
```

CI packs the reader on every change and prints the tarball's SHA-256; that
artifact is the one a project adopts. Packing the same source elsewhere
(`pnpm pack` in `reader/`) gives the same files with the same contents and
metadata, but the archive's digest can still differ: gzip records the operating
system that compressed it. Record the exact digest of the archive you commit,
and check it against that archive rather than against a local pack.

```jsonc
// package.json
"scripts": {
  "docs:dev": "ts-docs-fresh dev .",
  "docs:build": "ts-docs-fresh build . --out .docs-site",
  "docs:serve": "ts-docs-fresh serve .docs-site"
}
```

- **`dev`** reads the current sources and follows their edits. Open pages,
  expanded definitions and inspections are updated in place, and you keep
  your reading position.
- **`build`** writes a static site:
  - every page reachable from the home, Getting started, Files and Search
    pages, plus old addresses;
  - the browser code, the search catalog and the media those pages use;
  - `ts-docs-build.json`, which records what the site was built by and from.

  The same reader, compiler and sources build the same bytes, wherever the
  project is checked out. A failed build, including one during which the
  sources changed, leaves the previous site; replacing it moves the old
  directory aside and the new one in, so `--out` is briefly absent between
  the two. `--out` must be a new directory or a site an earlier build wrote.
- **`serve`** serves a built site.
  - **Type answers:** inspecting a name and expanding a definition are
    answered on demand from the project's sources, with the settings the site
    was built with.
  - **Refuses to start** if the sources, the reader or the compiler changed
    since the build.
  - **After an edit while serving:** pages are prepared again, as in `dev`.

  Behind a plain static file host, the pages, navigation, Search, Files and
  media work, but inspection and expansion cannot be answered.

  The site's links and the reader's requests are relative, so it can be
  mounted below a path (checked behind a proxy at `/docs/`: Search, API
  expansion, Source, a Files inspection's further levels and Definition).

Options:

- `--media-root <dir>`, or `HARNESS_MEDIA_ROOT`: a capture collection for
  Getting started's screenshots, videos and terminal recordings. The build
  copies the assets that match the media manifest.
- `--package-source <built>=<source>`: a built package directory and the
  sources compiled into it, beyond the package's `outDir` → `rootDir`. For
  example, `dist/reference-host=examples/reference-app`. Examples are read
  against the package's sources through this mapping.

## Host it on Vercel

`ts-docs-fresh vercel-output .docs-site` writes `.vercel/output`, a
[prebuilt output](https://vercel.com/docs/build-output-api) with three parts:

- **`static/`:** the built site, file by file as its manifest lists them.
- **`functions/_reader/query.func`:** a Node.js 24 function, with 4 GB and
  120 s. It answers `_reader/inspection`, `_reader/expansion` and
  `_reader/update` with the same code as `serve`. It holds:
  - the inputs the build read;
  - `inputs.json`, the SHA-256 of every file the function holds. An instance
    checks it, then the build manifest and the compiler, before answering. A
    changed, missing or added file fails every query with 503, while the
    pages still serve;
  - the installed declarations the compiler reads, for every project the site
    offers inspection in;
  - the site's captured media;
  - the native compiler build the site was built with.
  `vercel-output` prints the function's size by part: the compiler,
  installed declarations, project inputs, handler, manifest and media, and
  settings.
- **`config.json`:** sends those three routes to the function, and serves
  everything else as static files.

Its requirements:

- **Build on the host's platform.** The function answers only with the
  compiler the site was built with, which is identified by its executable. A
  site built on macOS gives an output for local emulation only, and the
  command says so. A deployable output is built on linux x64.
- **Install with `node-linker=hoisted`.** A function holds no links, so the
  project's `node_modules` must be real directories. Put
  `node-linker=hoisted` in an `.npmrc` beside `package.json`.
  - **Reinstalling the reader:** a hoisted install keeps an installed package
    of the same name and version. To take a new reader tarball, remove
    `node_modules/ts-docs-fresh` first.
- **Install the platform's compiler.** The compiler build for the host, for
  example `@typescript/typescript-linux-x64`, must be installed, as pnpm's
  `supportedArchitectures` does.
- **Live updates:** source edits have no meaning for a deployment, so
  `_reader/events` is a 404, and the reader does not retry it.

## What a consumer provides

The reader documents the sources and declarations the project has; it does
not run the project's build. Declarations a build generates must exist before
`docs:build`. For Glade, its `scripts/build.ts` writes
`dist/vendor/harness-world/*.d.ts` from `vendor/harness-world/*.tgz` and a
patch; without them these nine pages are absent:

- `interfaces/Hosting.DriveContext.html`
- `variables/Hosting.BACKSTOP_QUEUE.html`, `variables/Hosting.OWNER_QUEUE.html`,
  `variables/Hosting.QUEUE_NAME.html`, `variables/Hosting.QUEUE_PREFIX.html`
- `files/dist/vendor/harness-world/{backstop,driver,owners,types}.d.ts.html`

The consumer runs its own build first; Glade's hosted documentation build runs
`pnpm build` and then the reader. The reader itself does not build the project.

The project must be a Git work tree, because Git decides what is published,
as it did for the original reader. Files and `_media/` publish the project's
tracked files and its untracked files that aren't ignored. A file is published
only if it is a regular file inside the project with a name Files shows: not a
link, not hidden (`.github` and `.gitignore` excepted), not `.env*`, and not
under `node_modules/` or `dist/`.
- Generated declarations that the API is declared in, such as Glade's ignored
  `dist/vendor/harness-world`, still get their pages, but Files doesn't list
  them. Nothing else the compiler reads is published.
- Editing an ignore rule changes what is published.
- `dev` and `build` refuse to start without a Git inventory, rather than
  showing an empty Files as if it were complete. That covers a directory
  outside any repository and one that an enclosing repository ignores.
- A built site records the files it published in `ts-docs-build.json`.
  - `serve` and the hosted function publish exactly that list, from a
    project copied anywhere, with or without Git.
  - The site is served as built only while the sources it read are unchanged.
- Every page, link, inspection and media request checks the path it names
  before reading anything. It must be a plain project-relative path, and the
  project must publish it.

## Develop the reader

```sh
pnpm install --frozen-lockfile
pnpm type-check && pnpm test
pnpm test:journey        # needs the specimen: node scripts/prepare-specimen.ts <glade checkout>
pnpm pack                # dist/: the command as JavaScript, and the browser assets
```

`pnpm test` includes a native-compiler check of API expansion on a generated
project. The journey tests read a Glade checkout: `scripts/prepare-specimen.ts`
extracts a recorded Glade revision from a local checkout. The specimen is
its own Git work tree: one commit holding exactly the archived files.
- `.git/info/exclude` keeps `node_modules`, `dist/` and `.specimen.json` out of
  the inventory.
- The declarations Glade's build generated (`dist/vendor`) are copied in.
- Glade's installed packages are linked.
- `.specimen.json` records the revision, the paths and the commit.

`pnpm dev` reads the specimen, so `prepare-specimen.ts --replace` updates an
older specimen that has no Git of its own. The script is a development aid,
not a way to set up a consumer.
